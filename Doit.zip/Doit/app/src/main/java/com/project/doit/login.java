package com.project.doit;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by HP on 16-02-2018.
 */

public class login extends Activity {
    EditText user, pass;
    String u, p;
    SQLiteDatabase db;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // final GlobalClass globalvariable = (GlobalClass) getApplicationContext();
        setContentView(R.layout.login_class);
        user = (EditText) findViewById(R.id.editText3);
        pass = (EditText) findViewById(R.id.editText4);


        Button button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View view) {
                if (user.getText().toString().equals("") || pass.getText().toString().equals("")) {

                    Toast.makeText(login.this, "PLz enter the fields..!", Toast.LENGTH_LONG).show();
                } else {
                    u = user.getText().toString();
                    p = pass.getText().toString();
                    try {
                        db = openOrCreateDatabase("DOIT", SQLiteDatabase.CREATE_IF_NECESSARY, null);
                    } catch (Exception exception) {
                        exception.printStackTrace();
                    }
                    try {
                        Cursor cc = db.rawQuery("select * from user where email= '" + u + "' and pass= '" + p + "' ", null);


                        // User Login
                        if (cc.moveToFirst()) {
                            String temp = "";
                            if (cc != null) {
                                if (cc.getCount() > 0) {
                                    //return true;
                                    scan g = new scan();
                                    g.onPreExecute();

                                    Toast.makeText(login.this, "Welcome" + u, Toast.LENGTH_LONG).show();
                                    //globalvariable.Setusername(user.getText().toString().trim());
                                    //globalvariable.Setpassword(pass.getText().toString().trim());
                                    Intent i = new Intent(login.this, DoitorGetIt.class);
                                    startActivity(i);

                                } else {
                                    Toast.makeText(login.this, " Login Fails..!", Toast.LENGTH_LONG).show();
                                }
                            }
                        } else {
                            Toast.makeText(login.this, " Login Fails..!", Toast.LENGTH_LONG).show();

                        }


                        //	return false;
                    } catch (Exception exception) {
                        exception.printStackTrace();
                    }
                }
            }
        });


    }

    @SuppressLint("StaticFieldLeak")
    public class scan extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(login.this);
            pd.setTitle("Please Wait");
            pd.setMessage("Logging....");
            pd.setMax(200);
            pd.show();
        }

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            return null;
        }

    }


}




