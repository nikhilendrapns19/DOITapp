package com.project.doit;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by HP on 17-02-2018.
 */

public class SignUp extends Activity {
    EditText name,email,pass,ph;
    Button b1;
    SQLiteDatabase db;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);
        name=(EditText)findViewById(R.id.editText5);
        email=(EditText)findViewById(R.id.editText);
        pass=(EditText)findViewById(R.id.editText7);
        ph=(EditText)findViewById(R.id.editText9);
        b1=(Button)findViewById(R.id.button4);
        db=openOrCreateDatabase("DOIT", Context.MODE_PRIVATE,null);
        db.execSQL("create table if not exists user(name varchar(20),email varchar(30) PRIMARY KEY,pass varchar(10),mobile varchar(10));");
        b1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if(name.getText().toString().trim().length()==0||
                        email.getText().toString().trim().length()==0||
                        pass.getText().toString().trim().length()==0||
                        ph.getText().toString().trim().length()==0)
                {
                    Toast.makeText(SignUp.this,"Enter All The Values",Toast.LENGTH_SHORT).show();
                    return;
                }
                else if(ph.getText().toString().length()!=10)
                {
                    Toast.makeText(SignUp.this,"Enter Valid NUMBER",Toast.LENGTH_SHORT).show();
                }

                else {
                    db.execSQL("insert into user values('" + name.getText() + "','" + email.getText() + "','" + pass.getText() + "','" + ph.getText() + "');");
                    Toast.makeText(SignUp.this, "REGISTRATION SUCCESSFUL ", Toast.LENGTH_SHORT).show();


                    Intent m = new Intent(SignUp.this, login.class);
                    startActivity(m);
                }

            }
        });

    }




    }
