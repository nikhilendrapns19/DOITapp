package com.project.doit;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by HP on 18-02-2018.
 */

public class DoitorGetIt extends Activity
{
    SQLiteDatabase db;
    TextView id;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.doitorget);
        //final GlobalClass globalvariable = (GlobalClass)getApplicationContext();
        //id=(TextView)findViewById(R.id.textView6);
        //id.setText(globalvariable.GetUsername().toString());

        Button doitbtn=(Button)findViewById(R.id.doitbtn);
        doitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in=new Intent(DoitorGetIt.this,DoitorGetIt.class);
                startActivity(in);

            }
        });
        Button getitdonebtn=(Button)findViewById(R.id.getitdonebtn);
        getitdonebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent gt=new Intent(DoitorGetIt.this,Advpost.class);
                startActivity(gt);
            }
        });
        Button logoutbtn=(Button)findViewById(R.id.logoutbtn);
        logoutbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent log=new Intent(DoitorGetIt.this,login.class);
                startActivity(log);
            }
        });
        Button profilebtn=(Button)findViewById(R.id.profilebtn);
        profilebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* Cursor c=db.rawQuery("SELECT * FROM user where email='"+id.getText()+"'", null);
                if(c.getCount()==0)
                {
                    showMessage("Error", "No records found");
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while(c.moveToNext())
                {
                    buffer.append("Name: "+c.getString(0)+"\n");
                    buffer.append("EMail:"+c.getString(1)+"\n");
                    buffer.append("Password: "+c.getString(2)+"\n");
                    buffer.append("Phone: "+c.getString(3)+"\n\n");
                }
                showMessage("Client Details", buffer.toString());
                */
               Intent vi=new Intent(DoitorGetIt.this,Profilescreen.class);
               startActivity(vi);

            }
        });
    }
    /*public void showMessage(String title,String message)
    {
        Builder builder=new Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }*/
}
